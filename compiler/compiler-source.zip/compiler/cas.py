"""Offline CAS compiler terminal.

Pure Python stdlib. No dashboard, server, database, network, or installs.
The goal is to mirror the online compiler's terminal workflow while adding
offline terminal diagrams plus standalone SVG/HTML exports.
"""

from __future__ import annotations

import argparse
from html import escape
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import threading
import webbrowser
from typing import Any

if sys.version_info < (3, 12):
    raise SystemExit("CAS Offline Compiler Terminal requires Python 3.12+ for its preserved SVG renderer.")

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
# The offline backend must not change semantics when an unrelated native
# extension happens to be installed. Native use is explicit through casc.
sys.modules["cas_engine"] = None

from api.notation.compiler import CAS_GRAMMAR_BNF, compile_expression, compile_file, CompilationArtifact  # noqa: E402
from api.notation.pcba import CCDL_GRAMMAR, compile_ccdl, compile_ccdl_file, simulate_ccdl, simulate_ccdl_file  # noqa: E402
from api.notation.pcba_sim import MAX_STEPS  # noqa: E402
import cas_terminal  # noqa: E402
from cas_features import CAPABILITIES, activation_payload, install_learning_additions, nesting_text, nesting_payload, diagnostic_payload, result_detail  # noqa: E402
from cas_native import configure_native, compile_native, native_grammar, NativeBackendError  # noqa: E402
from cas_svg import render_svg  # noqa: E402
from cas_terminal import (  # noqa: E402
    EXAMPLES,
    U,
    ansi,
    banner_text,
    compiler_shell_html,
    dictionary_text,
    example_by_index,
    examples_text,
    highlight_ansi,
    learning_text,
    palette_text,
    play_banner_wave,
    play_compiling_spinner,
    reference_text,
    set_color_enabled,
    startup_hint_text,
    terminal_diagram,
)

install_learning_additions(cas_terminal)
BACKEND = "python"
LANGUAGE = "cas"
MAX_SIMULATION_INPUT_BYTES = 64 * 1024


def compile_selected(source: str = "", *, file_path: str | None = None, mode: str = "run",
                     simulation_inputs: dict[str, Any] | None = None,
                     simulation_steps: int | None = None) -> Any:
    if LANGUAGE == "ccdl":
        if simulation_steps is not None:
            return (simulate_ccdl_file(file_path, inputs=simulation_inputs, steps=simulation_steps)
                    if file_path else simulate_ccdl(source, inputs=simulation_inputs, steps=simulation_steps))
        return compile_ccdl_file(file_path, mode=mode) if file_path else compile_ccdl(source, mode=mode)
    if BACKEND == "native":
        return compile_native(file_path=file_path, mode=mode) if file_path else compile_native(source=source, mode=mode)
    try:
        return compile_file(file_path) if file_path else compile_expression(source)
    except (OSError, UnicodeError) as exc:
        return CompilationArtifact(source=source or str(file_path), tokens=[], ast=None,
                                   type_info=None, bytecode=[], result=None, valid=False,
                                   error=f"Unable to read CAS source: {exc}", engine="python")


def grammar_text() -> str:
    if LANGUAGE == "ccdl":
        return CCDL_GRAMMAR
    return native_grammar() if BACKEND == "native" else CAS_GRAMMAR_BNF


def print_stage(artifact: Any, mode: str) -> None:
    data = artifact.to_dict()
    keys = {"lex": ("tokens",), "parse": ("ast",), "check": ("type", "warnings")}[mode]
    payload = {key: data.get(key) for key in keys}
    payload.update(valid=artifact.valid, error=artifact.error, engine=artifact.engine)
    if "_native" in data:
        payload["_native"] = data["_native"]
    if data.get("language") == "ccdl":
        payload.update(language="ccdl", stage=data["stage"],
                       execution_status=data["execution_status"],
                       parse_status=data["parse_status"],
                       structural_status=data["structural_status"],
                       diagnostics=data["diagnostics"])
    print(json.dumps(payload, ensure_ascii=False, indent=2))


ALIASES = [
    (r"\bnotin\b", U["notin"]),
    (r"\bsubseteq\b", U["subseteq"]),
    (r"\bsubset\b", U["subset"]),
    (r"\bsupseteq\b", U["supseteq"]),
    (r"\bsupset\b", U["supset"]),
    (r"\bemptyset\b", U["empty"]),
    (r"\bin\b", U["in"]),
    (r"\bTheta\b", U["theta"]),
    (r"\bOmega(?=_|\b)", U["omega"]),
    (r"\bLambda(?=_|\b)", U["lambda"]),
    (r"\bkappa(?=_|\b)", U["kappa"]),
    (r"\biota(?=_|\b)", U["iota"]),
    (r"\beta\b", U["eta"]),
    (r"\bPhi\b", U["phi"]),
]


HELP = f"""\
Commands:
  :help          Show this message
  :grammar       Print the BNF grammar
  :capabilities  Show backend support and limits
  :language cas|ccdl  Select CAS expressions or structural CCDL documents
  :load PATH     Compile a local file in the selected language
  :activations   Show the last Python AST register annotations (not model data)
  :examples      Show the same grouped examples as the online compiler
  :natural       Show examples in natural language
  :mirror        Show (CAS expression) natural-language mirror pairs
  :dict [TERM]   Show the CAS dictionary, optionally filtered
  :learn         Show the guided compiler learning path
  :example N     Compile example number N
  :demo          Compile every example and write demo SVG/HTML files
  :palette       Show hard-to-type CAS symbols
  :ref           Show Noetics, Domains, Drives, and Registers
  :history       Show command history
  :clear         Clear terminal output
  :diagram       Print the last diagram JSON
  :svg PATH      Save the last diagram as SVG
  :html PATH     Save the last diagram as standalone HTML
  :open          Open the last diagram in your default browser
  :preview       Alias for :open
  :json on/off   Toggle full JSON output
  :files on/off  Toggle automatic cas_diagram.svg/html writes
  :quit          Exit

Editing:
  CAS: newline or ; separates statements. CCDL uses its declared grammar.
  --file / :load preserves file source exactly, including quoted paths.
  CCDL: use :load for a multiline document; no CAS aliases are rewritten.
  Bounded scalar simulation is a one-shot command: --language ccdl --file PATH
    --simulate --inputs INPUTS.json --steps N [--trace TRACE.json].

ASCII aliases:
  in / notin / subset / subseteq / supset / supseteq / emptyset
  Theta / Omega / Lambda / kappa / iota / eta / Phi

Visual output:
  The terminal prints a compact diagram preview every time the compiler emits
  one. The full static visual is written to SVG/HTML offline.
  In the REPL you can append save flags directly:
    Product(Noetics, Domains) --svg product.svg --html product.html
"""


def expand(text: str) -> str:
    if LANGUAGE == "ccdl":
        return text
    # Preserve strings, escape sequences, line comments, and statement breaks.
    # Native source belongs to its own grammar and is never rewritten here.
    parts = re.split(r'("(?:[^"\\]|\\.)*"|\#[^\r\n]*|//[^\r\n]*)', text)
    for index in range(0, len(parts), 2):
        for pattern, replacement in ALIASES:
            parts[index] = re.sub(pattern, replacement, parts[index])
    return "".join(parts)


def write_text(path: str | Path, text: str) -> Path:
    out = Path(path).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    return out


def load_simulation_inputs(path: str | Path) -> dict[str, Any]:
    """Read an explicit bounded JSON request without permissive JSON extensions."""
    with Path(path).open("rb") as handle:
        raw = handle.read(MAX_SIMULATION_INPUT_BYTES + 1)
    if len(raw) > MAX_SIMULATION_INPUT_BYTES:
        raise ValueError("simulation input JSON exceeds 64 KiB")

    def object_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate simulation input JSON key: {key!r}")
            result[key] = value
        return result

    def constant(value: str) -> Any:
        raise ValueError(f"non-finite JSON number is not allowed: {value}")

    def number(value: str) -> Any:
        raise ValueError("simulation decimal values must be quoted exact decimal text; "
                         "JSON decimal or exponent numbers are not accepted")

    request = json.loads(raw.decode("utf-8"), object_pairs_hook=object_pairs,
                         parse_constant=constant, parse_float=number)
    if not isinstance(request, dict):
        raise ValueError("simulation input JSON must be an object")
    return request


def append_html_panel(html: str, panel: str) -> str:
    # The preserved shell omits an explicit body end tag. Bind to its actual
    # main close, and fail visibly if a later template change removes it.
    if "</main>" not in html:
        raise ValueError("Offline HTML template has no main closing marker; extra result data cannot be exported.")
    return html.replace("</main>", "</main>" + panel, 1)


def render_outputs(
    artifact: Any,
    *,
    svg_path: str | Path | None = None,
    html_path: str | Path | None = None,
    title: str = "CAS Diagram",
) -> tuple[Path | None, Path | None]:
    diagram = artifact.diagram()
    if not diagram or (not diagram.get("nodes") and not diagram.get("containers")):
        if svg_path or html_path:
            print("  diagram unavailable for this result; no SVG/HTML file was written")
        return None, None
    data = artifact.to_dict()
    source_text = data.get("source") if isinstance(data.get("source"), str) else title
    result = data.get("result")
    svg = render_svg(diagram, result=result, title=source_text)
    detail = nesting_text(result) if BACKEND == "python" else ""
    domain_detail = result_detail(result) if BACKEND == "python" else ""
    diagnostic_records = diagnostic_payload(result) if BACKEND == "python" else []
    warning_text = "\n".join(str(w) for w in data.get("warnings") or [])
    if detail or domain_detail or warning_text:
        svg = svg.replace("</svg>", "<desc>" + escape("\n".join(
            text for text in (detail, domain_detail, warning_text) if text)) + "</desc></svg>")
    if diagnostic_records:
        svg = svg.replace("</svg>", '<metadata id="cas-pcba-ohm-results">'
                          + escape(json.dumps(diagnostic_records, ensure_ascii=False, indent=2))
                          + "</metadata></svg>")
    saved_svg = write_text(svg_path, svg) if svg_path else None
    if html_path:
        data["diagram"] = diagram
        preview = terminal_diagram(diagram, result, title=source_text)
        html = compiler_shell_html(
            source=source_text,
            artifact_data=data,
            svg=svg,
            terminal_preview=preview,
            title="CAS Offline Compiler",
        )
        if detail:
            html = html.replace("<p>Fractal [", "<p>Legacy composed_operator projection [")
            notes = escape(json.dumps(nesting_payload(result), ensure_ascii=False, indent=2))
            panel = ('<section style="margin:24px;padding:24px;background:#0d1117;color:#cbd5e1;overflow:auto">'
                     '<h2>Nesting readings — source structure and canonical form are separate</h2>'
                     '<pre>' + notes + '</pre></section>')
            html = append_html_panel(html, panel)
        if diagnostic_records:
            panel = ('<section style="margin:24px;padding:24px;background:#0d1117;color:#cbd5e1;overflow:auto">'
                     '<h2>PCBA and CAS-Ohm results</h2><pre>'
                     + escape(json.dumps(diagnostic_records, ensure_ascii=False, indent=2))
                     + '</pre></section>')
            html = append_html_panel(html, panel)
        if warning_text:
            panel = ('<section style="margin:24px;padding:24px;background:#0d1117;color:#fbbf24;overflow:auto">'
                     '<h2>Compiler warnings</h2><pre>' + escape(warning_text) + '</pre></section>')
            html = append_html_panel(html, panel)
        saved_html = write_text(html_path, html)
    else:
        saved_html = None
    return saved_svg, saved_html


def result_line(result: Any) -> str:
    if not isinstance(result, dict):
        return ""
    kind = result.get("kind")
    if kind == "state":
        return f"{result.get('dominant_operator', '?')} in {result.get('dominant_domain', '?')} domain"
    if kind == "fractal":
        seq = ":".join(str(x) for x in result.get("sequence", []))
        return f"Fractal [{seq}]; legacy composed_operator={result.get('composed_operator', '?')} (see nesting readings)"
    if kind == "rpm":
        completeness = result.get("completeness", 0)
        return f"{result.get('drive', '?')} prerequisite chain ({completeness:.0%})"
    if kind == "meta_assertion":
        mark = U["check"] if result.get("holds") is True else U["cross"] if result.get("holds") is False else "?"
        return f"{result.get('message', result.get('operator', 'assertion'))} {mark}"
    if kind == "meta_set":
        card = result.get("cardinality")
        return f"{result.get('name', 'set')} ({card} elements)" if isinstance(card, int) else str(result.get("name", "set"))
    if kind == "recipe":
        target = result.get("target", "?")
        count = len(result.get("prerequisites") or [])
        return f"Recipe -> {U['omega']}_{target} from {count} prerequisite(s)"
    if kind == "program":
        return "Multi-statement program"
    return json.dumps(result, ensure_ascii=False)[:160]


def summarize(
    artifact: Any,
    *,
    source: str,
    full_json: bool = False,
    show_terminal_diagram: bool = True,
) -> None:
    data = artifact.to_dict()
    if not artifact.valid:
        print(f"  {ansi('INVALID', 'red', bold=True)}: {artifact.error}")
        if full_json:
            print(json.dumps(data, ensure_ascii=False, indent=2))
        return

    print(
        f"  {ansi('valid', 'green', bold=True)} (engine={artifact.engine}, "
        f"tokens={len(artifact.tokens)}, bytecode={len(artifact.bytecode)})"
    )
    if data.get("type"):
        type_info = data["type"]
        singular = " singular" if type_info.get("singular") else ""
        print(f"  type: {ansi(type_info['kind'], 'violet')}{singular}")

    for warning in data.get("warnings") or []:
        print(f"  warning: {warning}")
    short = (json.dumps(data.get("result"), ensure_ascii=False)[:240]
             if BACKEND == "native" else result_line(data.get("result")))
    if short:
        print(f"  meaning: {short}")
    detail = nesting_text(data.get("result")) if BACKEND == "python" else ""
    if detail:
        print(detail)
    domain_detail = result_detail(data.get("result")) if BACKEND == "python" else ""
    if domain_detail:
        print(domain_detail)
    result = data.get("result") if BACKEND == "python" else None
    while isinstance(result, dict) and result.get("kind") == "program":
        result = result.get("final_result")
    if isinstance(result, dict) and result.get("kind") in {"recipe", "yield", "yield_expression", "production_target", "state_vector"}:
        print("  symbolic structure only; no numerical production yield was calculated")
    if BACKEND == "native":
        print("  diagram: unavailable (native casc does not emit diagram data)")

    diagram = artifact.diagram()
    if diagram and (diagram.get("nodes") or diagram.get("containers")):
        print(
            f"  diagram: layouts={diagram.get('layouts')} "
            f"nodes={len(diagram.get('nodes', []))} "
            f"edges={len(diagram.get('edges', []))} "
            f"containers={len(diagram.get('containers', []))}"
        )
        if show_terminal_diagram:
            print(terminal_diagram(diagram, data.get("result"), title=source))

    if full_json:
        print(json.dumps(data, ensure_ascii=False, indent=2))


def compile_with_spinner(expanded: str, *, file_path: str | None = None,
                         simulation_inputs: dict[str, Any] | None = None,
                         simulation_steps: int | None = None) -> Any:
    """Run compile_expression(expanded) with a background "compiling" spinner.

    Spinner only renders after a short delay (handled inside
    play_compiling_spinner) so fast compiles do not flicker. Compile runs
    synchronously on the main thread; the spinner is a daemon thread that is
    signaled via threading.Event when the compile returns. On Ctrl+C the
    spinner is still stopped and its line cleared.
    """
    stop_event = threading.Event()
    spinner_thread = threading.Thread(
        target=play_compiling_spinner,
        args=(stop_event,),
        daemon=True,
    )
    spinner_thread.start()
    try:
        artifact = compile_selected(expanded, file_path=file_path,
                                    simulation_inputs=simulation_inputs, simulation_steps=simulation_steps)
    finally:
        stop_event.set()
        spinner_thread.join(timeout=1.0)
    return artifact


def compile_and_show(
    source: str,
    *,
    full_json: bool = False,
    show_terminal_diagram: bool = True,
    svg_path: str | Path | None = None,
    html_path: str | Path | None = None,
    auto_files: bool = False,
    echo_source: bool = True,
    file_path: str | None = None,
    simulation_inputs: dict[str, Any] | None = None,
    simulation_steps: int | None = None,
) -> tuple[Any, Path | None, Path | None]:
    expanded = source if LANGUAGE == "ccdl" else source.strip() if BACKEND == "native" or file_path else expand(source.strip())
    if echo_source:
        print(f"{ansi(LANGUAGE + '>', 'accent_light', bold=True)} {highlight_ansi(expanded)}")
    artifact = compile_with_spinner(expanded, file_path=file_path,
                                    simulation_inputs=simulation_inputs, simulation_steps=simulation_steps)
    artifact_source = artifact.to_dict().get("source")
    if isinstance(artifact_source, str):
        expanded = artifact_source
    summarize(
        artifact,
        source=expanded,
        full_json=full_json,
        show_terminal_diagram=show_terminal_diagram,
    )
    saved_svg = saved_html = None
    if artifact.valid:
        if auto_files:
            svg_path = svg_path or "cas_diagram.svg"
            html_path = html_path or "cas_diagram.html"
        saved_svg, saved_html = render_outputs(
            artifact,
            svg_path=svg_path,
            html_path=html_path,
            title=expanded,
        )
        if saved_svg:
            print(f"  svg: {saved_svg}")
        if saved_html:
            print(f"  html: {saved_html}")
    return artifact, saved_svg, saved_html


def parse_repl_inline_options(raw: str) -> tuple[str, dict[str, Any], list[str]]:
    """Parse one-shot-style save flags typed inside the REPL."""
    opts: dict[str, Any] = {
        "svg_path": None,
        "html_path": None,
        "auto_files": None,
        "full_json": None,
        "show_terminal_diagram": None,
        "color": None,
    }
    errors: list[str] = []
    text = raw

    def outside_literal(match: re.Match[str]) -> bool:
        flag_start = match.start() + len(match.group(0)) - len(match.group(0).lstrip())
        protected = re.finditer(r'"(?:[^"\\]|\\.)*"|\x27[^\x27]*\x27|\#[^\r\n]*|//[^\r\n]*', text)
        return not any(part.start() <= flag_start < part.end() for part in protected)

    def pull_path(flag: str, key: str) -> None:
        nonlocal text
        pattern = re.compile(rf"(^|\s){re.escape(flag)}\s+(\"[^\"]+\"|'[^']+'|\S+)")
        match = next((item for item in pattern.finditer(text) if outside_literal(item)), None)
        if not match:
            if any(outside_literal(item) for item in re.finditer(rf"(^|\s){re.escape(flag)}(?=\s|$)", text)):
                errors.append(f"{flag} requires a path")
            return
        opts[key] = match.group(2).strip("\"'")
        text = text[: match.start()] + " " + text[match.end() :]

    pull_path("--svg", "svg_path")
    pull_path("--html", "html_path")

    for flag, key, value in (
        ("--auto-files", "auto_files", True),
        ("--json", "full_json", True),
        ("--no-terminal-diagram", "show_terminal_diagram", False),
        ("--color", "color", True),
        ("--no-color", "color", False),
    ):
        pattern = re.compile(rf"(^|\s){re.escape(flag)}(?=\s|$)")
        matches = [item for item in pattern.finditer(text) if outside_literal(item)]
        if matches:
            opts[key] = value
            for item in reversed(matches):
                text = text[:item.start()] + " " + text[item.end():]

    expr = text.strip()
    return expr, opts, errors


def demo(output_dir: str | Path = "examples") -> int:
    if LANGUAGE != "cas":
        print("The numbered demos use CAS. Select --language cas; CCDL examples use --language ccdl --file PATH.")
        return 2
    if BACKEND == "native":
        print("Demo SVG/HTML export requires the Python backend; native diagrams are unavailable.")
        return 2
    out = Path(output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    failures = 0
    print(f"Writing example diagrams to {out}")
    for i, example in enumerate(EXAMPLES, 1):
        source = expand(example["expr"])
        artifact = compile_selected(source)
        status = "valid" if artifact.valid else f"INVALID: {artifact.error}"
        print(f"{i:02d}. {example['label']}: {status}")
        if not artifact.valid:
            failures += 1
            continue
        stem = f"{i:02d}_{slug(example['label'])}"
        render_outputs(
            artifact,
            svg_path=out / f"{stem}.svg",
            html_path=out / f"{stem}.html",
            title=source,
        )
    print(f"done: {len(EXAMPLES) - failures} valid, {failures} invalid")
    return 1 if failures else 0


def slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_").lower() or "example"


def clear_screen() -> None:
    os.system("cls" if os.name == "nt" else "clear")


# Cache paths used by the :open / :preview REPL commands.
# After every successful compile in the REPL we write the rendered diagram
# to these paths so :open always has something fresh to show. If the user
# explicitly saves via :svg PATH or :html PATH that path takes precedence.
CACHE_HTML_PATH = Path(tempfile.gettempdir()) / f"cas-successor-{os.getpid()}" / "last_diagram.html"
CACHE_SVG_PATH = CACHE_HTML_PATH.with_suffix(".svg")

# Most-recent explicit path, set by :svg PATH or :html PATH. Preferred by :open.
_LAST_EXPLICIT_PATH: Path | None = None
_LAST_PREVIEW_PATH: Path | None = None


def _cache_last_diagram(artifact: Any, title: str) -> Path | None:
    """Write the artifact's diagram to the OS-temp cache so :open can find it.

    Returns the cached HTML path on success, or None if the artifact has no
    renderable diagram. Failures (permission, disk full, etc.) are swallowed
    silently so they never disrupt the REPL flow.
    """
    global _LAST_PREVIEW_PATH
    _LAST_PREVIEW_PATH = None
    try:
        diagram = artifact.diagram()
        if not diagram or (not diagram.get("nodes") and not diagram.get("containers")):
            return None
        _LAST_PREVIEW_PATH = render_outputs(
            artifact,
            svg_path=CACHE_SVG_PATH,
            html_path=CACHE_HTML_PATH,
            title=title,
        )[1]
        return _LAST_PREVIEW_PATH
    except Exception:
        return None


def _open_last_diagram() -> bool:
    """Open the most recent diagram in the default browser.

    Preference order: explicit user-saved path (from :svg/:html) > cached HTML.
    Returns True if a diagram was opened, False if nothing was available.
    """
    candidate: Path | None = None
    if _LAST_EXPLICIT_PATH is not None and _LAST_EXPLICIT_PATH.exists():
        candidate = _LAST_EXPLICIT_PATH
    elif _LAST_PREVIEW_PATH is not None and _LAST_PREVIEW_PATH.exists():
        candidate = _LAST_PREVIEW_PATH
    if candidate is None:
        return False
    url = candidate.resolve().as_uri()
    webbrowser.open(url)
    return True


def repl() -> int:
    global _LAST_EXPLICIT_PATH, _LAST_PREVIEW_PATH, LANGUAGE
    play_banner_wave()
    print(f"\n{startup_hint_text()}\n")
    print(f"Backend: {BACKEND}; language: {LANGUAGE}. Type :capabilities for supported features and limits.")
    last_artifact: Any | None = None
    last_source = "CAS Diagram"
    full_json = False
    auto_files = BACKEND == "python"
    history: list[str] = []

    while True:
        try:
            raw = input(f"{LANGUAGE}> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not raw:
            continue

        if raw in {":quit", ":q", "exit"}:
            return 0
        if raw == ":help":
            print(HELP)
            continue
        if raw == ":capabilities":
            print(CAPABILITIES)
            continue
        if raw == ":language" or raw.startswith(":language "):
            requested = raw.split(maxsplit=1)[1].strip() if " " in raw else ""
            if requested not in {"cas", "ccdl"}:
                print("  usage: :language cas|ccdl")
            elif requested == "ccdl" and BACKEND != "python":
                print("  CCDL requires the Python backend. Restart with --backend python --language ccdl.")
            else:
                LANGUAGE = requested
                last_artifact = None
                last_source = "CAS Diagram"
                _LAST_EXPLICIT_PATH = _LAST_PREVIEW_PATH = None
                print(f"  language: {LANGUAGE}")
            continue
        if raw == ":activations":
            if LANGUAGE != "cas" or BACKEND != "python" or last_artifact is None or not last_artifact.valid:
                print("  register annotations require a valid previous Python CAS result")
            else:
                print(json.dumps(activation_payload(last_artifact), ensure_ascii=False, indent=2))
            continue
        if raw.startswith(":load "):
            path = raw.split(maxsplit=1)[1].strip().strip('"')
            _LAST_EXPLICIT_PATH = _LAST_PREVIEW_PATH = None
            last_artifact, _, _ = compile_and_show(path, file_path=path, full_json=full_json, auto_files=auto_files)
            last_source = last_artifact.to_dict().get("source", path)
            history.insert(0, raw)
            if last_artifact.valid:
                _cache_last_diagram(last_artifact, last_source)
            continue
        if raw == ":examples":
            print(examples_text())
            continue
        if raw == ":natural":
            print(examples_text("natural"))
            continue
        if raw == ":mirror":
            print(examples_text("mirror"))
            continue
        if raw == ":dict" or raw.startswith(":dict "):
            query = raw.split(maxsplit=1)[1] if " " in raw else ""
            print(dictionary_text(query))
            continue
        if raw == ":learn":
            print(learning_text())
            continue
        if raw.startswith(":example "):
            if LANGUAGE != "cas":
                print("  numbered examples use CAS; select :language cas. Load CCDL examples with :load PATH.")
                continue
            try:
                idx = int(raw.split(maxsplit=1)[1])
            except ValueError:
                print("  usage: :example N")
                continue
            expr = example_by_index(idx)
            if not expr:
                print(f"  example {idx} does not exist")
                continue
            print(f"{ansi('cas>', 'accent_light', bold=True)} {highlight_ansi(expr)}")
            history.insert(0, expr)
            _LAST_EXPLICIT_PATH = _LAST_PREVIEW_PATH = None
            last_artifact, _, _ = compile_and_show(
                expr,
                full_json=full_json,
                show_terminal_diagram=True,
                auto_files=auto_files,
                echo_source=False,
            )
            last_source = expand(expr)
            if last_artifact is not None and last_artifact.valid:
                _cache_last_diagram(last_artifact, last_source)
            continue
        if raw == ":demo":
            demo()
            continue
        if raw == ":palette":
            print(palette_text())
            continue
        if raw == ":ref":
            print(reference_text())
            continue
        if raw == ":history":
            if not history:
                print("  (empty)")
            else:
                for i, item in enumerate(history[:50], 1):
                    print(f"  {i:>2}. {item}")
            continue
        if raw == ":clear":
            clear_screen()
            print(banner_text())
            continue
        if raw == ":grammar":
            try:
                print(grammar_text())
            except NativeBackendError as exc:
                print(f"  native grammar unavailable: {exc}")
            continue
        if raw == ":diagram":
            if last_artifact is None:
                print("  no previous diagram")
                continue
            print(json.dumps(last_artifact.diagram(), ensure_ascii=False, indent=2))
            continue
        if raw.startswith(":json"):
            full_json = raw.endswith("on")
            print(f"  json {'on' if full_json else 'off'}")
            continue
        if raw.startswith(":files"):
            auto_files = raw.endswith("on")
            print(f"  files {'on' if auto_files else 'off'}")
            continue
        if raw.startswith(":svg ") or raw.startswith(":html "):
            if last_artifact is None or not last_artifact.valid:
                print("  no valid previous diagram")
                continue
            cmd, path = raw.split(maxsplit=1)
            saved_svg, saved_html = render_outputs(
                last_artifact,
                svg_path=path if cmd == ":svg" else None,
                html_path=path if cmd == ":html" else None,
                title=last_source,
            )
            saved = saved_svg or saved_html
            if saved is not None:
                _LAST_EXPLICIT_PATH = Path(saved).resolve()
                print(f"  saved: {saved}")
            continue
        if raw in {":open", ":preview"}:
            if last_artifact is not None and last_artifact.valid and _open_last_diagram():
                target = _LAST_EXPLICIT_PATH if _LAST_EXPLICIT_PATH else CACHE_HTML_PATH
                print(f"  opening {target} in default browser")
            else:
                print("  (no diagram yet — compile something first)")
            continue

        expr, opts, errors = parse_repl_inline_options(raw)
        if errors:
            print("  " + "; ".join(errors))
            continue
        if opts["color"] is not None:
            set_color_enabled(opts["color"])
            print(f"  color {'on' if opts['color'] else 'off'}")
        if not expr:
            if last_artifact is None or not last_artifact.valid:
                print(
                    "  no valid previous diagram; enter an expression first or use: "
                    "Product(Noetics, Domains) --svg product.svg --html product.html"
                )
                continue
            saved_svg, saved_html = render_outputs(
                last_artifact,
                svg_path=opts["svg_path"],
                html_path=opts["html_path"],
                title=last_source,
            )
            if saved_svg or saved_html:
                print(f"  saved: {saved_svg or saved_html}")
            else:
                print("  no output path supplied; use --svg PATH and/or --html PATH")
            continue

        history.insert(0, expr)
        _LAST_EXPLICIT_PATH = _LAST_PREVIEW_PATH = None
        last_artifact, inline_svg, inline_html = compile_and_show(
            expr,
            full_json=opts["full_json"] if opts["full_json"] is not None else full_json,
            show_terminal_diagram=opts["show_terminal_diagram"] if opts["show_terminal_diagram"] is not None else True,
            svg_path=opts["svg_path"],
            html_path=opts["html_path"],
            auto_files=opts["auto_files"] if opts["auto_files"] is not None else auto_files,
            echo_source=False,
        )
        last_source = expr if BACKEND == "native" else expand(expr)
        if last_artifact is not None and last_artifact.valid:
            _cache_last_diagram(last_artifact, last_source)
            # An inline --svg/--html save also counts as an explicit path for :open.
            explicit = inline_html or inline_svg
            if explicit is not None:
                _LAST_EXPLICIT_PATH = Path(explicit).resolve()


def compile_once(args: argparse.Namespace) -> int:
    if args.capabilities:
        print(CAPABILITIES)
        return 0
    if args.grammar:
        try:
            print(grammar_text())
            return 0
        except NativeBackendError as exc:
            print(f"Native grammar unavailable: {exc}", file=sys.stderr)
            return 2
    if args.examples:
        print(examples_text())
        return 0
    if args.natural:
        print(examples_text("natural"))
        return 0
    if args.mirror:
        print(examples_text("mirror"))
        return 0
    if args.dictionary is not None:
        print(dictionary_text(args.dictionary))
        return 0
    if args.learn:
        print(learning_text())
        return 0
    if args.palette:
        print(palette_text())
        return 0
    if args.reference:
        print(reference_text())
        return 0
    if args.demo:
        return demo(args.demo_dir)
    if BACKEND == "native" and (args.svg or args.html or args.auto_files or args.auto_svg or args.auto_html or args.activations):
        print("Native diagrams/exports and Python register annotations are unavailable. Use --backend python.", file=sys.stderr)
        return 2
    if args.manifest and BACKEND != "native":
        print("--manifest requires --backend native and --casc-path. Python files use --file.", file=sys.stderr)
        return 2
    if args.mode != "run" and (args.svg or args.html or args.auto_files or args.auto_svg or args.auto_html or args.activations):
        print("Exports and register annotations require --mode run.", file=sys.stderr)
        return 2
    if args.example is not None:
        if LANGUAGE != "cas":
            print("--example uses CAS. For CCDL, use --language ccdl --file PATH.", file=sys.stderr)
            return 2
        expr = example_by_index(args.example)
        if not expr:
            print(f"example {args.example} does not exist")
            return 2
        source = expr
    else:
        source = " ".join(args.expression)
        if LANGUAGE != "ccdl":
            source = source.strip()
    if not source and not args.file_path and not args.manifest:
        print("No expression supplied. Run without arguments for REPL mode.")
        return 2

    simulation_inputs = None
    if args.simulate:
        try:
            simulation_inputs = load_simulation_inputs(args.inputs_path)
        except (OSError, UnicodeError, ValueError, RecursionError) as exc:
            print(f"Simulation inputs rejected before execution: {exc}", file=sys.stderr)
            return 2

    if args.mode != "run":
        artifact = (compile_native(manifest_path=args.manifest, mode=args.mode)
                    if args.manifest else compile_selected(source if BACKEND == "native" else expand(source),
                                                          file_path=args.file_path, mode=args.mode))
        print_stage(artifact, args.mode)
        return 0 if artifact.valid else 1
    if args.manifest:
        artifact = compile_native(manifest_path=args.manifest)
        summarize(artifact, source=args.manifest, full_json=args.json, show_terminal_diagram=False)
        return 0 if artifact.valid else 1

    auto_files = args.auto_files or args.auto_svg or args.auto_html
    svg_path = args.svg
    html_path = args.html
    if args.auto_svg and not svg_path:
        svg_path = "cas_diagram.svg"
    if args.auto_html and not html_path:
        html_path = "cas_diagram.html"

    artifact, _, _ = compile_and_show(
        source or args.file_path,
        full_json=args.json,
        show_terminal_diagram=not args.no_terminal_diagram,
        svg_path=svg_path,
        html_path=html_path,
        auto_files=auto_files,
        file_path=args.file_path,
        simulation_inputs=simulation_inputs,
        simulation_steps=args.steps if args.simulate else None,
    )
    if args.trace_path:
        simulation = (artifact.result or {}).get("simulation")
        if simulation is None:
            print("Simulation did not start; no trace report is available.", file=sys.stderr)
        else:
            try:
                trace_path = write_text(args.trace_path, json.dumps(
                    simulation, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            except (OSError, ValueError) as exc:
                print(f"Unable to write simulation trace report: {exc}", file=sys.stderr)
                return 2
            print(f"  trace report: {trace_path}")
    if args.activations and artifact.valid:
        print(json.dumps({"register_annotations": activation_payload(artifact),
                          "meaning": "AST positions and registers; not measured model activations"},
                         ensure_ascii=False, indent=2))
    return 0 if artifact.valid else 1


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Offline CAS compiler terminal with diagrams.")
    parser.add_argument("expression", nargs="*", help="CAS expression. Omit for REPL mode.")
    parser.add_argument("--language", choices=["cas", "ccdl"], default="cas", help="CAS expressions or supported structural PCBA/CCDL documents.")
    parser.add_argument("--file", dest="file_path", help="Compile an unchanged UTF-8 file in the selected language; CAS supports relative module imports.")
    parser.add_argument("--manifest", help="Native-only Cas.toml / caspkg.toml or package directory.")
    parser.add_argument("--mode", choices=["lex", "parse", "check", "run"], default="run", help="CAS: output view of full compilation (native lex/parse are frontend only). CCDL: lex, parse, or structural check; run checks unless --simulate is explicitly supplied.")
    parser.add_argument("--simulate", action="store_true", help="Explicitly run a bounded CCDL numerical profile; requires --inputs and --steps. Ordinary CCDL run remains a structural check.")
    parser.add_argument("--inputs", dest="inputs_path", help="Explicit UTF-8 simulation request JSON file (at most 64 KiB); decimal values must be quoted exact decimal text.")
    parser.add_argument("--steps", type=int, help=f"Explicit simulation step count, 1 through {MAX_STEPS}.")
    parser.add_argument("--trace", dest="trace_path", help="Write the numerical simulation report and trace as strict JSON, including any runtime rejection.")
    parser.add_argument("--grammar", action="store_true", help="Print selected backend grammar.")
    parser.add_argument("--capabilities", action="store_true", help="Print supported features and limits.")
    parser.add_argument("--activations", action="store_true", help="Show Python AST register annotations, not model measurements.")
    parser.add_argument("--backend", choices=["python", "native"], default="python", help="Select bundled Python or explicitly configured external casc.")
    parser.add_argument("--casc-path", help="Absolute path to an existing native casc executable; never auto-discovered.")
    parser.add_argument("--json", action="store_true", help="Print full artifact JSON.")
    parser.add_argument("--svg", help="Write diagram SVG to this path.")
    parser.add_argument("--html", help="Write standalone diagram HTML to this path.")
    parser.add_argument("--auto-svg", action="store_true", help="Write cas_diagram.svg when --svg is omitted.")
    parser.add_argument("--auto-html", action="store_true", help="Write cas_diagram.html when --html is omitted.")
    parser.add_argument("--auto-files", action="store_true", help="Write both cas_diagram.svg and cas_diagram.html.")
    parser.add_argument("--no-terminal-diagram", action="store_true", help="Suppress terminal diagram preview.")
    parser.add_argument("--examples", action="store_true", help="Print grouped examples.")
    parser.add_argument("--natural", action="store_true", help="Print examples in natural language.")
    parser.add_argument("--mirror", action="store_true", help="Print (CAS expression) natural-language mirror pairs.")
    parser.add_argument("--dict", nargs="?", const="", dest="dictionary", help="Print the CAS dictionary, optionally filtered by term.")
    parser.add_argument("--learn", action="store_true", help="Print the guided compiler learning path.")
    parser.add_argument("--example", type=int, help="Compile example number N.")
    parser.add_argument("--demo", action="store_true", help="Compile every example and write SVG/HTML demo files.")
    parser.add_argument("--demo-dir", default="examples", help="Output folder for --demo.")
    parser.add_argument("--palette", action="store_true", help="Print symbol palette.")
    parser.add_argument("--reference", action="store_true", help="Print reference panel.")
    parser.add_argument("--color", action="store_true", help="Force ANSI color output.")
    parser.add_argument("--no-color", action="store_true", help="Disable ANSI color output.")
    args = parser.parse_args(argv)
    if sum(bool(x) for x in (args.expression, args.file_path, args.manifest, args.example is not None)) > 1:
        parser.error("choose exactly one expression, --file, --manifest, or --example")
    if args.backend == "python" and args.casc_path:
        parser.error("--casc-path requires --backend native")
    if args.language == "ccdl" and args.backend != "python":
        parser.error("--language ccdl requires --backend python")
    if args.language == "ccdl" and args.manifest:
        parser.error("CCDL documents use --file, not --manifest")
    if args.language == "ccdl" and args.activations:
        parser.error("--activations is a CAS AST view and is unavailable for CCDL")
    if not args.simulate and any(value is not None for value in (args.inputs_path, args.steps, args.trace_path)):
        parser.error("--inputs, --steps and --trace require --simulate")
    if args.simulate:
        if args.language != "ccdl" or args.backend != "python" or args.mode != "run":
            parser.error("--simulate requires --language ccdl --backend python --mode run")
        if not args.inputs_path or args.steps is None:
            parser.error("--simulate requires explicit --inputs PATH and --steps N")
        if not 1 <= args.steps <= MAX_STEPS:
            parser.error(f"--steps must be between 1 and {MAX_STEPS}")
        if not (args.expression or args.file_path):
            parser.error("--simulate requires a CCDL expression or --file PATH")
        if (args.grammar or args.capabilities or args.examples or args.natural or args.mirror
                or args.dictionary is not None or args.learn or args.example is not None
                or args.demo or args.palette or args.reference):
            parser.error("--simulate cannot be combined with informational or example commands")
        if args.trace_path:
            trace_path = Path(args.trace_path).expanduser().resolve()
            protected = [args.file_path, args.inputs_path, args.svg, args.html]
            if args.auto_files or args.auto_svg:
                protected.append(args.svg or "cas_diagram.svg")
            if args.auto_files or args.auto_html:
                protected.append(args.html or "cas_diagram.html")
            if any(path and trace_path == Path(path).expanduser().resolve() for path in protected):
                parser.error("--trace must differ from the source, inputs, SVG and HTML paths")
    if args.mode != "run" and not (args.expression or args.file_path or args.manifest or args.example is not None):
        parser.error("--mode requires an expression, --file, --manifest, or --example")
    return args


def main(argv: list[str] | None = None) -> int:
    global BACKEND, LANGUAGE
    args = parse_args(argv if argv is not None else sys.argv[1:])
    BACKEND = args.backend
    LANGUAGE = args.language
    if BACKEND == "native":
        try:
            configure_native(args.casc_path)
        except (ValueError, OSError) as exc:
            print(f"Native compiler unavailable: {exc}", file=sys.stderr)
            return 2
    set_color_enabled(True if args.color else False if args.no_color else None)
    direct = (
        args.expression
        or args.examples
        or args.natural
        or args.mirror
        or args.dictionary is not None
        or args.learn
        or args.example is not None
        or args.demo
        or args.palette
        or args.reference
        or args.file_path
        or args.manifest
        or args.grammar
        or args.capabilities
    )
    if not direct:
        return repl()
    return compile_once(args)


if __name__ == "__main__":
    raise SystemExit(main())
